using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr12_4
{
    public partial class Form1 :Form
    {
        public Form1 ()
        {
            InitializeComponent();

        }
        Sportsmen sportsmen = new Sportsmen();
        private void Form1_Load (object sender, EventArgs e)
        {
        
        }
        
        private void button1_Click (object sender, EventArgs e)
        {
            double years;
            double rost;
            double ves;
           
            try
            {
               
                if (textBox1.Text == "" && textBox2.Text == "" && textBox3.Text == "" || textBox4.Text == "" && textBox4.Text == "" && textBox6.Text == "" && textBox7.Text == "" && textBox8.Text== "")
                {
                    MessageBox.Show("Заполните все поля");
                    return;
                }
                else
                {
                    if (!double.TryParse(textBox1.Text, out double result))
                    {
                        string name = textBox1.Text;
                        sportsmen.Name = name;
                    }
                    else
                    {
                        MessageBox.Show("В поле Имя неккоректный ввод данных");
                        return;
                    }
                    if (!double.TryParse(textBox2.Text, out double result1))
                    {
                        string fname = textBox2.Text;
                        sportsmen.fname = fname;
                    }
                    else
                    {
                        MessageBox.Show("В поле Фамилия неккоректный ввод данных");
                        return;
                    }
                    if (!double.TryParse(textBox3.Text, out double result2))
                    {
                        string lname = textBox1.Text;
                        sportsmen.Name = lname;
                    }
                    else
                    {
                        MessageBox.Show("В поле Отчество неккоректный ввод данных");
                        return;
                    }
                    if (!double.TryParse(textBox4.Text, out double result4))
                    {
                        string pol = textBox4.Text;
                       
                        
                        if (pol.ToLower() == "женский" || pol.ToLower()== "мужской")
                        {
                            sportsmen.SetPol(pol);
                            
                        }
                        else
                        {
                            MessageBox.Show("пол может быть или женским или мужским");
                            return;
                            
                        }
                    }
                    else
                    {
                        MessageBox.Show("В поле Пол неккоректный ввод данных");
                        return;
                    }
                    if (!double.TryParse(textBox8.Text, out double result5))
                    {
                        string vidsp = textBox8.Text;
                        sportsmen.vidsp = vidsp;
                    }
                    else
                    {
                        MessageBox.Show("В поле Вид спорта неккоректный ввод данных");
                        return;
                    }

                    if (double.TryParse(textBox5.Text, out years))
                    {
                        sportsmen.SetYears(years);
                        if (years <= 0 || years >= 100)
                        {
                            MessageBox.Show("Возраст не может быть <=0 или больше 100");
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show("нужно ввести число в поле возраст");
                        return;
                    }
                    if (double.TryParse(textBox6.Text, out rost))
                    {
                        sportsmen.SetRost(rost);
                        if (rost <= 0 || rost >= 200)
                        {
                            MessageBox.Show("Рост не может быть <=0 или больше 200");
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show("нужно ввести число в поле рост");
                        return;
                    }
                    if (double.TryParse(textBox7.Text, out ves))
                    {
                        sportsmen.SetVes(ves);
                        if (ves <= 30 || ves>= 200)
                        {
                            MessageBox.Show("Вес не может быть <=30 или больше 200");
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show("нужно ввести число в поле вес");
                        return;
                    } 
                }
               
                double idvesBrok = sportsmen.IdvesBrok();
                double idvesKupper = sportsmen.IdvesKupper();
                string info = sportsmen.GetInfo();
                MessageBox.Show(info);
            }
            catch
            {
                MessageBox.Show("Ошибка");
            }
          




        }
    }
}
