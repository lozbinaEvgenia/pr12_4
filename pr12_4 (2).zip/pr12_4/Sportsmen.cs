﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr12_4
{
    public class Sportsmen
    {
        public string Name;
        public string fname;
        public string lname;
        private string pol;
        private double years;
        private double rost;
        private double ves;
        public string vidsp;
      
        public double GetYears()
        {
            return this.years;
        }
        public string GetPol()
        {
            return this.pol;
        }
        public void SetYears(double years)
        {
            this.years = years;
        }
        public void SetPol(string pol)
        {
            this.pol = pol;
        }
        public void SetVes(double ves)
        {
            this.ves = ves;
        }
        public double GetVes()
        {
            return this.ves;
        }
        public void SetRost(double rost)
        {
            this.rost = rost;
        }
        public double GetRost()
        {
            double rost = this.rost;
            return rost;
        }
        public double IdvesBrok()
        {
           
            double idves = 0;
            if (years < 40 && years > 0)
                idves = rost - 110;
            else if (years >= 40)
                idves = rost - 100;
            return idves;
        }
        public double IdvesKupper()
        {
            double idves = 0;
            if (pol.ToLower() == "женский")
                idves = Math.Round((rost * 3.5 / 2.54 - 108) * 0.453);
            else if (pol.ToLower()== "мужской")
                idves = Math.Round((rost * 4.0 / 2.54 - 128) * 0.453);
            return idves;
        }
        public string GetInfo()
        {
            string message = $"Имя: {Name}\nОтчество: {fname}\nФамилия: {lname}\nПол: {pol}\nВозраст: {years}\nРост: {rost}\nВес: {ves}\nВид спорта: {vidsp}\nИдеальный вес по формуле Брока:{IdvesBrok()}\nИдеальный вес по формуле Купера:{IdvesKupper()}";
                return message;
        }


    }
}
